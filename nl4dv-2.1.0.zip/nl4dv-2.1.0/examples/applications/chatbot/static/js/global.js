(function(){

    globalConfig = {
        "botui": null,
        "ambiguity_response": {},
		"metadataMap" : {},
        "conversation": [],
        "resolved": {}
    };
})();
